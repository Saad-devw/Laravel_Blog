

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <a href="/posts/create" class="btn btn-info my-3">Add Post</a>
                    <!--<?php echo e(__('You are logged in!')); ?>-->
                    <h3>Your Posts :</h3>
                    <?php if(count($posts) > 0): ?>
                        <table class="table table-striped">
                            <tr>
                                <th>Title</th>
                                <th></th>
                                <th></th>
                            </tr>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($post->title); ?></td>
                                    <td><a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-info">Edit</a></td>
                                    <td>
                                        <?php echo Form::open(['action' =>['App\Http\Controllers\PostsController@destroy', $post-> id], 'method'=> 'POST', 'class'=> 'float-end']); ?>

                                            <?php echo e(Form::submit('Delete', ['class'=> 'btn btn-danger'])); ?>

                                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    <?php else: ?>
                        <p class="bg-light text-center py-3">No posts yet!</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\code\Laravel_Blog\resources\views/dashboard.blade.php ENDPATH**/ ?>