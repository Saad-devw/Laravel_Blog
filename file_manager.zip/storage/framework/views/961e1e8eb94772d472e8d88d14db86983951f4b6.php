
<?php $__env->startSection('content'); ?>
    <h1>Create New Post :</h1>
    <?php echo Form::open(['action' => '\App\Http\Controllers\PostsController@store', 'Method' => 'POST', 'enctype'=> 'multipart/form-data']); ?>

      <div class="form-group">
        <?php echo e(Form:: label('title', 'Title')); ?>

        <?php echo e(Form:: text('title', '', ['class' => 'form-control', 'placeholder' => 'Enter post title'])); ?>

      </div>
      
      <div class="form-control my-2">
        <?php echo e(Form::file('file')); ?>

      </div>
      <?php echo e(Form:: submit('Submit', ['class' => 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\code\Laravel_Blog\resources\views/posts/create.blade.php ENDPATH**/ ?>