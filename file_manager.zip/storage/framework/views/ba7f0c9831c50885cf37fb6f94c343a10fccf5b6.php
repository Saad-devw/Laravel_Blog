
<?php $__env->startSection('content'); ?>
    <h1>Modifier Fichier :</h1>
    <?php echo Form::open(['action' => ['\App\Http\Controllers\PostsController@update', $post->id], 'Method' => 'POST', 'enctype'=> 'multipart/form-data']); ?>

      <div class="form-group">
        <?php echo e(Form:: label('title', 'Titre')); ?>

        <?php echo e(Form:: text('title', $post->title, ['class' => 'form-control shadow-none', 'placeholder' => 'Enter post title'])); ?>

      </div>
      
      <?php echo e(Form::hidden('_method', 'PUT')); ?>

      <div class="form-group">
        <?php echo e(Form:: label('file', 'Fichier')); ?>

        <?php echo e(Form::file('file', ['class' => 'form-control shadow-none'])); ?>

      </div>
      
      <div class="d-flex justify-content-between my-3"> 
        <?php echo e(Form:: submit('Submit', ['class' => 'btn btn-primary'])); ?>

        <a href="/posts/<?php echo e($post->id); ?>" class="btn btn-secondary">Annuler</a>
      </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\code\Laravel_Blog\resources\views/posts/edit.blade.php ENDPATH**/ ?>