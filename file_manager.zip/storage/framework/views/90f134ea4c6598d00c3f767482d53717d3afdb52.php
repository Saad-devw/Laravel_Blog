

<?php $__env->startSection('content'); ?>
    <div class="py-5 text-center">
      <h1>Welcome To Laravel</h1>
      <p>This is laravel application , designed by saad essadiki</p>
      <?php if(!Auth::check()): ?>
        <p><a href="/login" class="btn btn-primary btn-lg">Login</a> <a href="/register" class="btn btn-success btn-lg">Register</a></p>
      <?php else: ?>
        <h6 class="mt-5 bg-success p-3 rounded text-light shadow-lg">Bonjour, : <?php echo e(Auth::user()->name); ?> / <?php echo e(Auth::user()->email); ?></h6>
      <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\code\Laravel_Blog\resources\views/pages/index.blade.php ENDPATH**/ ?>