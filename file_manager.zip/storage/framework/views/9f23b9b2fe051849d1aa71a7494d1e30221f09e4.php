
<?php /**PATH C:\Users\DELL\Documents\code\Laravel_Blog\resources\views/includes/footer.blade.php ENDPATH**/ ?>