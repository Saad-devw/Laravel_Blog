
<?php $__env->startSection('content'); ?>
    <h3 class="my-4">Tout Les Fichiers :</h3>
    <?php $count = 0; ?>
    <?php if(count($posts) > 0): ?>
    <div class="row justify-content-center py-3 px-2 my-3 files">
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="/storage/files/<?php echo e($post->file); ?>" download="<?php echo e($post->file); ?>" class="col-sm-3 m-2 border shadow-sm">
          <div class="col-sm-12">
              <img src="./assets/images/download.jpg" alt="<?php echo e($post-> title); ?>" width="100%">
          </div>
          <div class="col-sm-12">
              <div class="text-center">
                  <h3><?php echo e($post -> title); ?></h3>
                  
                  <small class="text-right">Créé Le: <?php echo e($post -> created_at); ?> Par <?php echo e($post->user->name); ?> </small>
              </div>
          </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="d-flex justify-content-center">
        <?php echo e($posts->links('pagination::bootstrap-4')); ?>

      </div>
    <?php else: ?>
      <p>No Posts Found!</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\code\Laravel_Blog\resources\views/posts/index.blade.php ENDPATH**/ ?>