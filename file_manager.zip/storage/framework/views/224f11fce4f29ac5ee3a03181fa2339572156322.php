
  <?php $__env->startSection('content'); ?>
      <a href="/posts" class="btn btn-secondary my-4"> Retour </a>
      <h3 class="text-center my-2 title"> <?php echo e($post->title); ?> </h3>
      <div class="col-md-12 text-center my-3">
        <embed src="/storage/files/<?php echo e($post->file); ?>" type="application/pdf" width="100%" height="700px">
      </div>
      <div class="col-md-12">
        <small class="text-right form-text">Créé le: <?php echo e($post -> created_at); ?> Par <?php echo e($post->user->name); ?></small>
      </div>
      <hr>
      <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $post -> user_id): ?>
          <div class="d-flex justify-content-between">
              <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-warning">Modifier</a>

              <?php echo Form::open(['action' =>['App\Http\Controllers\PostsController@destroy', $post-> id], 'method'=> 'POST', 'class'=> 'float-end']); ?>

                <?php echo e(Form::submit('Supprimer', ['class'=> 'btn btn-danger'])); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

              <?php echo Form::close(); ?>

          </div>
        <?php endif; ?>
      <?php endif; ?>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\code\Laravel_Blog\resources\views/posts/post.blade.php ENDPATH**/ ?>