# Laravel_Blog
Small Blog Application using Laravel 8
###
# Requirements
    1.  XAMPP:
        put source code inside htdocs folder in xampp directory | Or you can use Production server (# Run App)
    2.  PHP.
    3.  COMPOSER:
        you can install them from their official website
    4.  Import database inside 'MySQL_Database' Folder with the same name 'lrblog' in 'phpmyadmin'
###
# Run App:
    first you nees to install packages by running :
        *   "$ npm install"
    you can run the app in two ways :
        1. go to localhost where XAMPP is running , and navigate to your app folder, then to 'public'  folder.
    OR:
        2. run this commande :
        "$ php artisan serve " and your server will start at "(http://127.0.0.1:8000)"
###
# Happy Coding
    
